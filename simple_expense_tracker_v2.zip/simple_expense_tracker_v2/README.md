# Simple Expense Tracker (v2) - Demo App
Light-mode Flask demo with categories + pie chart.

## Features
- Add / View / Delete expenses
- Each expense has Category, Item, Amount, Date
- Pie chart summary (Chart.js) showing spending by category
- SQLite database (file: expenses.db)

## Run locally
1. Create virtualenv and activate:
   python -m venv venv
   source venv/bin/activate   # macOS/Linux
   venv\Scripts\activate    # Windows

2. Install requirements:
   pip install -r requirements.txt

3. Run the app:
   python app.py

4. Open http://127.0.0.1:5000 in your browser.

## Notes
- Database is created automatically on first run.
- To reset DB, delete `expenses.db`.
