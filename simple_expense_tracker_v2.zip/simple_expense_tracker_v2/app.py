from flask import Flask, render_template, request, redirect, url_for, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///expenses.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Expense(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    item = db.Column(db.String(120), nullable=False)
    category = db.Column(db.String(80), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    date = db.Column(db.Date, nullable=False, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'item': self.item,
            'category': self.category,
            'amount': self.amount,
            'date': self.date.isoformat()
        }

@app.before_first_request
def create_tables():
    db.create_all()

@app.route('/')
def index():
    expenses = Expense.query.order_by(Expense.date.desc()).all()
    total = sum(e.amount for e in expenses)
    return render_template('index.html', expenses=expenses, total=total)

@app.route('/add', methods=['GET','POST'])
def add():
    categories = ['Food','Travel','Rent','Books','Entertainment','Other']
    if request.method == 'POST':
        item = request.form.get('item','').strip()
        category = request.form.get('category','Other').strip()
        amount = request.form.get('amount','0').strip()
        date_str = request.form.get('date','').strip()
        if not item or not amount:
            return "Please provide item and amount", 400
        try:
            amt = float(amount)
        except:
            return "Invalid amount", 400
        if date_str:
            try:
                d = datetime.strptime(date_str, '%Y-%m-%d').date()
            except:
                d = datetime.utcnow().date()
        else:
            d = datetime.utcnow().date()
        e = Expense(item=item, category=category, amount=amt, date=d)
        db.session.add(e)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('add.html', categories=categories)

@app.route('/delete/<int:id>', methods=['POST'])
def delete(id):
    e = Expense.query.get_or_404(id)
    db.session.delete(e)
    db.session.commit()
    return redirect(url_for('index'))

# API endpoint for chart data
@app.route('/api/category-totals')
def category_totals():
    from sqlalchemy import func
    rows = db.session.query(Expense.category, func.sum(Expense.amount)).group_by(Expense.category).all()
    data = {r[0]: float(r[1]) for r in rows}
    return jsonify(data)

if __name__ == '__main__':
    # create DB if running directly
    if not os.path.exists('expenses.db'):
        with app.app_context():
            db.create_all()
    app.run(debug=True)
