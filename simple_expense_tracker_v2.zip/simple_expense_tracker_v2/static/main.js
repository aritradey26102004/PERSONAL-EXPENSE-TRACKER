// placeholder for any JS
console.log('Expense Tracker (light mode) loaded.');
